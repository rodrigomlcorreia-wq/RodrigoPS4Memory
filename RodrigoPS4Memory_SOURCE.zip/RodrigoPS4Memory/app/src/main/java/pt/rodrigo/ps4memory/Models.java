package pt.rodrigo.ps4memory;

import java.util.Locale;

final class Models {
    private Models() {}

    static final class ProcessInfo {
        final String name;
        final int pid;
        ProcessInfo(String name, int pid) { this.name = name; this.pid = pid; }
        @Override public String toString() { return name + "  [PID " + pid + "]"; }
    }

    static final class MemoryMap {
        final long start, end, offset, prot;
        final String name;
        MemoryMap(long start, long end, long offset, long prot, String name) {
            this.start = start; this.end = end; this.offset = offset; this.prot = prot; this.name = name;
        }
        long size() { return end - start; }
        boolean readable() { return (prot & 1L) != 0; }
        @Override public String toString() {
            return String.format(Locale.US, "%016X-%016X  %s  %s", start, end, readable() ? "R" : "-", name);
        }
    }

    static final class ScanResult {
        final long address;
        byte[] lastValue;
        ScanResult(long address, byte[] lastValue) { this.address = address; this.lastValue = lastValue; }
    }
}
