package pt.rodrigo.ps4memory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

final class MemoryScanner {
    enum Refine { EXACT, CHANGED, UNCHANGED, INCREASED, DECREASED }
    interface Progress { void onProgress(long done, long total, int results, String mapName); }

    private static final int CHUNK = 1024 * 1024;
    private static final int MAX_RESULTS = 200_000;
    private final AtomicBoolean cancelled = new AtomicBoolean();

    void cancel() { cancelled.set(true); }

    List<Models.ScanResult> firstExact(Ps4DebugClient client, int pid, List<Models.MemoryMap> maps,
                                       ValueCodec.Type type, byte[] needle, Progress progress) throws IOException {
        cancelled.set(false);
        List<Models.ScanResult> results = new ArrayList<>();
        long total = 0;
        for (Models.MemoryMap m : maps) if (eligible(m)) total += m.size();
        long done = 0;

        for (Models.MemoryMap m : maps) {
            if (!eligible(m) || cancelled.get()) continue;
            long pos = m.start;
            while (pos < m.end && !cancelled.get()) {
                int len = (int)Math.min(CHUNK, m.end - pos);
                try {
                    byte[] buf = client.readMemory(pid, pos, len);
                    int step = Math.max(1, type.size);
                    for (int i = 0; i + type.size <= buf.length; i += step) {
                        boolean match = true;
                        for (int j = 0; j < type.size; j++) {
                            if (buf[i+j] != needle[j]) { match = false; break; }
                        }
                        if (match) {
                            results.add(new Models.ScanResult(pos + i, Arrays.copyOfRange(buf, i, i + type.size)));
                            if (results.size() >= MAX_RESULTS) return results;
                        }
                    }
                } catch (IOException readError) {
                    // A single unreadable hole should not kill a full process scan.
                }
                pos += len;
                done += len;
                if (progress != null) progress.onProgress(done, total, results.size(), m.name);
            }
        }
        return results;
    }

    List<Models.ScanResult> refine(Ps4DebugClient client, int pid, List<Models.ScanResult> current,
                                   ValueCodec.Type type, Refine mode, byte[] exactValue, Progress progress) {
        cancelled.set(false);
        List<Models.ScanResult> keep = new ArrayList<>();
        int i = 0;
        for (Models.ScanResult r : current) {
            if (cancelled.get()) break;
            try {
                byte[] now = client.readMemory(pid, r.address, type.size);
                boolean ok;
                switch (mode) {
                    case EXACT: ok = ValueCodec.equal(type, now, exactValue); break;
                    case CHANGED: ok = !ValueCodec.equal(type, now, r.lastValue); break;
                    case UNCHANGED: ok = ValueCodec.equal(type, now, r.lastValue); break;
                    case INCREASED: ok = ValueCodec.asDouble(type, now) > ValueCodec.asDouble(type, r.lastValue); break;
                    case DECREASED: ok = ValueCodec.asDouble(type, now) < ValueCodec.asDouble(type, r.lastValue); break;
                    default: ok = false;
                }
                if (ok) keep.add(new Models.ScanResult(r.address, now));
            } catch (Exception ignored) {}
            i++;
            if (progress != null && (i % 64 == 0 || i == current.size())) progress.onProgress(i, current.size(), keep.size(), "refine");
        }
        return keep;
    }

    private boolean eligible(Models.MemoryMap m) {
        if (!m.readable()) return false;
        long size = m.size();
        return size > 0 && size <= (2L * 1024 * 1024 * 1024);
    }
}
