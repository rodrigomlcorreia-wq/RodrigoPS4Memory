package pt.rodrigo.ps4memory;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;

import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Ps4DebugClient client = new Ps4DebugClient();
    private final MemoryScanner scanner = new MemoryScanner();
    private final FreezeManager freeze = new FreezeManager();

    private EditText ip, value, writeValue;
    private TextView status, scanStatus;
    private Spinner processSpinner, typeSpinner;
    private ArrayAdapter<Models.ProcessInfo> processAdapter;
    private ArrayAdapter<String> resultAdapter;
    private ListView resultList;
    private ProgressBar progress;

    private List<Models.ProcessInfo> processes = new ArrayList<>();
    private List<Models.MemoryMap> maps = new ArrayList<>();
    private List<Models.ScanResult> results = new ArrayList<>();
    private int selectedResult = -1;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scroll.addView(root);

        TextView title = text("Rodrigo PS4 Memory", 24); root.addView(title);
        root.addView(text("ps4debug-NG • TCP 744", 14));

        LinearLayout conn = row();
        ip = edit("IP da PS4 (ex: 192.168.1.50)"); ip.setText("192.168.1.50");
        conn.addView(ip, new LinearLayout.LayoutParams(0, -2, 1));
        Button connect = button("Ligar"); conn.addView(connect); root.addView(conn);
        status = text("Desligado", 14); root.addView(status);

        LinearLayout procRow = row();
        processSpinner = new Spinner(this);
        processAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, processes);
        processSpinner.setAdapter(processAdapter);
        procRow.addView(processSpinner, new LinearLayout.LayoutParams(0, -2, 1));
        Button refresh = button("Processos"); procRow.addView(refresh); root.addView(procRow);

        root.addView(text("Tipo de valor", 16));
        typeSpinner = new Spinner(this);
        typeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"INT8", "INT16", "INT32", "INT64", "FLOAT", "DOUBLE"}));
        typeSpinner.setSelection(2); root.addView(typeSpinner);

        value = edit("Valor a procurar (ex: 5)"); value.setInputType(InputType.TYPE_CLASS_TEXT); root.addView(value);

        LinearLayout scanButtons = row();
        Button newScan = button("Nova pesquisa");
        Button exact = button("Exato");
        Button changed = button("Mudou");
        scanButtons.addView(newScan, new LinearLayout.LayoutParams(0,-2,1));
        scanButtons.addView(exact, new LinearLayout.LayoutParams(0,-2,1));
        scanButtons.addView(changed, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(scanButtons);

        LinearLayout refineButtons = row();
        Button increased = button("Aumentou");
        Button decreased = button("Diminuiu");
        Button unchanged = button("Igual");
        refineButtons.addView(increased, new LinearLayout.LayoutParams(0,-2,1));
        refineButtons.addView(decreased, new LinearLayout.LayoutParams(0,-2,1));
        refineButtons.addView(unchanged, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(refineButtons);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000); root.addView(progress, new LinearLayout.LayoutParams(-1, -2));
        scanStatus = text("Sem pesquisa", 14); root.addView(scanStatus);

        Button cancel = button("Cancelar pesquisa"); root.addView(cancel);

        resultList = new ListView(this); resultList.setNestedScrollingEnabled(true);
        resultAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_activated_1, new ArrayList<>());
        resultList.setAdapter(resultAdapter); resultList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        root.addView(resultList, new LinearLayout.LayoutParams(-1, 620));

        root.addView(text("Editar resultado selecionado", 16));
        writeValue = edit("Novo valor"); root.addView(writeValue);
        LinearLayout writeRow = row();
        Button write = button("Escrever");
        Button freezeBtn = button("Freeze ON/OFF");
        writeRow.addView(write, new LinearLayout.LayoutParams(0,-2,1));
        writeRow.addView(freezeBtn, new LinearLayout.LayoutParams(0,-2,1)); root.addView(writeRow);

        TextView note = text("Dica Shadow of War: começa por INT32. Ex.: tens 5 pontos → pesquisa 5 → gasta 1 → mete 4 → Exato. Repete até sobrarem poucos endereços.", 14);
        root.addView(note);

        connect.setOnClickListener(v -> connect());
        refresh.setOnClickListener(v -> refreshProcesses());
        processSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { loadMaps(); }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        newScan.setOnClickListener(v -> firstScan());
        exact.setOnClickListener(v -> refine(MemoryScanner.Refine.EXACT));
        changed.setOnClickListener(v -> refine(MemoryScanner.Refine.CHANGED));
        increased.setOnClickListener(v -> refine(MemoryScanner.Refine.INCREASED));
        decreased.setOnClickListener(v -> refine(MemoryScanner.Refine.DECREASED));
        unchanged.setOnClickListener(v -> refine(MemoryScanner.Refine.UNCHANGED));
        cancel.setOnClickListener(v -> scanner.cancel());
        resultList.setOnItemClickListener((p,v,pos,id) -> { selectedResult = pos; updateSelectedValue(); });
        write.setOnClickListener(v -> writeSelected(false));
        freezeBtn.setOnClickListener(v -> toggleFreeze());

        return scroll;
    }

    private void connect() {
        setStatus("A ligar...");
        worker.execute(() -> {
            try {
                client.connect(ip.getText().toString().trim(), 5000);
                String ver = client.version();
                ui(() -> { setStatus("Ligado • ps4debug-NG " + ver); refreshProcesses(); });
            } catch (Exception e) { ui(() -> setStatus("Erro: " + e.getMessage())); }
        });
    }

    private void refreshProcesses() {
        if (!client.isConnected()) { setStatus("Liga primeiro à PS4."); return; }
        worker.execute(() -> {
            try {
                List<Models.ProcessInfo> list = client.listProcesses();
                list.sort(Comparator.comparing(a -> a.name.toLowerCase(Locale.ROOT)));
                ui(() -> {
                    processes.clear(); processes.addAll(list); processAdapter.notifyDataSetChanged();
                    int eboot = -1;
                    for (int i=0;i<processes.size();i++) if (processes.get(i).name.toLowerCase(Locale.ROOT).contains("eboot")) { eboot=i; break; }
                    if (eboot >= 0) processSpinner.setSelection(eboot);
                    setStatus("Processos: " + list.size());
                });
            } catch (Exception e) { ui(() -> setStatus("Erro processos: " + e.getMessage())); }
        });
    }

    private void loadMaps() {
        Models.ProcessInfo p = selectedProcess(); if (p == null || !client.isConnected()) return;
        worker.execute(() -> {
            try {
                List<Models.MemoryMap> m = client.maps(p.pid);
                ui(() -> { maps = m; setStatus("PID " + p.pid + " • " + m.size() + " memory maps"); });
            } catch (Exception e) { ui(() -> setStatus("Erro maps: " + e.getMessage())); }
        });
    }

    private void firstScan() {
        Models.ProcessInfo p = selectedProcess(); if (p == null) return;
        ValueCodec.Type type = selectedType();
        final byte[] needle;
        try { needle = ValueCodec.encode(type, value.getText().toString()); }
        catch (Exception e) { setStatus("Valor inválido"); return; }
        if (maps.isEmpty()) { setStatus("Ainda sem memory maps."); return; }
        scanStatus.setText("A pesquisar...");
        worker.execute(() -> {
            try {
                List<Models.ScanResult> found = scanner.firstExact(client, p.pid, maps, type, needle, this::progress);
                ui(() -> { results = found; refreshResultList(); scanStatus.setText("Resultados: " + results.size()); });
            } catch (Exception e) { ui(() -> scanStatus.setText("Erro scan: " + e.getMessage())); }
        });
    }

    private void refine(MemoryScanner.Refine mode) {
        Models.ProcessInfo p = selectedProcess(); if (p == null || results.isEmpty()) return;
        ValueCodec.Type type = selectedType();
        byte[] exactValue = null;
        if (mode == MemoryScanner.Refine.EXACT) {
            try { exactValue = ValueCodec.encode(type, value.getText().toString()); }
            catch (Exception e) { setStatus("Valor inválido"); return; }
        }
        final byte[] target = exactValue;
        worker.execute(() -> {
            List<Models.ScanResult> narrowed = scanner.refine(client, p.pid, results, type, mode, target, this::progress);
            ui(() -> { results = narrowed; selectedResult = -1; refreshResultList(); scanStatus.setText("Resultados: " + results.size()); });
        });
    }

    private void progress(long done, long total, int count, String map) {
        int p = total <= 0 ? 0 : (int)Math.min(1000, (done * 1000L) / total);
        ui(() -> { progress.setProgress(p); scanStatus.setText("Resultados " + count + " • " + (p/10.0) + "% • " + map); });
    }

    private void refreshResultList() {
        List<String> rows = new ArrayList<>();
        ValueCodec.Type type = selectedType();
        int max = Math.min(results.size(), 5000);
        for (int i=0;i<max;i++) {
            Models.ScanResult r = results.get(i);
            rows.add(String.format(Locale.US, "0x%016X   %s", r.address, ValueCodec.format(type, r.lastValue)));
        }
        if (results.size() > max) rows.add("… " + (results.size()-max) + " resultados não mostrados");
        resultAdapter.clear(); resultAdapter.addAll(rows); resultAdapter.notifyDataSetChanged();
    }

    private void updateSelectedValue() {
        if (selectedResult < 0 || selectedResult >= results.size()) return;
        Models.ProcessInfo p = selectedProcess(); ValueCodec.Type t = selectedType(); Models.ScanResult r = results.get(selectedResult);
        worker.execute(() -> {
            try {
                byte[] now = client.readMemory(p.pid, r.address, t.size); r.lastValue = now;
                ui(() -> { writeValue.setText(ValueCodec.format(t, now)); refreshResultList(); });
            } catch (Exception e) { ui(() -> setStatus("Erro leitura: " + e.getMessage())); }
        });
    }

    private void writeSelected(boolean fromFreeze) {
        if (selectedResult < 0 || selectedResult >= results.size()) { setStatus("Seleciona um endereço."); return; }
        Models.ProcessInfo p = selectedProcess(); ValueCodec.Type t = selectedType(); Models.ScanResult r = results.get(selectedResult);
        final byte[] bytes;
        try { bytes = ValueCodec.encode(t, writeValue.getText().toString()); }
        catch (Exception e) { setStatus("Novo valor inválido"); return; }
        worker.execute(() -> {
            try {
                client.writeMemory(p.pid, r.address, bytes); r.lastValue = bytes.clone();
                if (!fromFreeze) ui(() -> { setStatus("Escrito em 0x" + Long.toHexString(r.address).toUpperCase(Locale.ROOT)); refreshResultList(); });
            } catch (Exception e) { ui(() -> setStatus("Erro escrita: " + e.getMessage())); }
        });
    }

    private void toggleFreeze() {
        if (freeze.active()) { freeze.stop(); setStatus("Freeze desligado"); return; }
        if (selectedResult < 0 || selectedResult >= results.size()) { setStatus("Seleciona um endereço."); return; }
        Models.ProcessInfo p = selectedProcess(); ValueCodec.Type t = selectedType(); Models.ScanResult r = results.get(selectedResult);
        try {
            byte[] bytes = ValueCodec.encode(t, writeValue.getText().toString());
            freeze.start(client, p.pid, r.address, bytes);
            setStatus("Freeze ON em 0x" + Long.toHexString(r.address).toUpperCase(Locale.ROOT));
        } catch (Exception e) { setStatus("Valor inválido"); }
    }

    private Models.ProcessInfo selectedProcess() {
        Object x = processSpinner.getSelectedItem(); return x instanceof Models.ProcessInfo ? (Models.ProcessInfo)x : null;
    }
    private ValueCodec.Type selectedType() { return ValueCodec.Type.valueOf(typeSpinner.getSelectedItem().toString()); }
    private void setStatus(String s) { status.setText(s); }
    private void ui(Runnable r) { runOnUiThread(r); }

    private LinearLayout row() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); return x; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); return b; }
    private EditText edit(String hint) { EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true); return e; }
    private TextView text(String s, int sp) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(0,8,0,8); return t; }

    @Override protected void onDestroy() {
        super.onDestroy(); scanner.cancel(); freeze.close(); client.close(); worker.shutdownNow();
    }
}
