package pt.rodrigo.ps4memory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;

final class ValueCodec {
    enum Type {
        INT8(1), INT16(2), INT32(4), INT64(8), FLOAT(4), DOUBLE(8);
        final int size;
        Type(int size) { this.size = size; }
    }

    private ValueCodec() {}

    static byte[] encode(Type type, String text) {
        ByteBuffer b = ByteBuffer.allocate(type.size).order(ByteOrder.LITTLE_ENDIAN);
        switch (type) {
            case INT8: b.put((byte) parseLong(text)); break;
            case INT16: b.putShort((short) parseLong(text)); break;
            case INT32: b.putInt((int) parseLong(text)); break;
            case INT64: b.putLong(parseLong(text)); break;
            case FLOAT: b.putFloat(Float.parseFloat(text.trim().replace(',', '.'))); break;
            case DOUBLE: b.putDouble(Double.parseDouble(text.trim().replace(',', '.'))); break;
        }
        return b.array();
    }

    static double asDouble(Type type, byte[] bytes) {
        ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        switch (type) {
            case INT8: return b.get();
            case INT16: return b.getShort();
            case INT32: return b.getInt();
            case INT64: return b.getLong();
            case FLOAT: return b.getFloat();
            case DOUBLE: return b.getDouble();
            default: throw new IllegalArgumentException();
        }
    }

    static String format(Type type, byte[] bytes) {
        ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        switch (type) {
            case INT8: return Byte.toString(b.get());
            case INT16: return Short.toString(b.getShort());
            case INT32: return Integer.toString(b.getInt());
            case INT64: return Long.toString(b.getLong());
            case FLOAT: return String.format(Locale.US, "%.6g", b.getFloat());
            case DOUBLE: return String.format(Locale.US, "%.9g", b.getDouble());
            default: return "?";
        }
    }

    static boolean equal(Type type, byte[] a, byte[] b) {
        if (a.length != b.length) return false;
        if (type == Type.FLOAT || type == Type.DOUBLE) {
            return Double.compare(asDouble(type, a), asDouble(type, b)) == 0;
        }
        for (int i = 0; i < a.length; i++) if (a[i] != b[i]) return false;
        return true;
    }

    static long parseLong(String s) {
        s = s.trim();
        if (s.startsWith("0x") || s.startsWith("0X")) return Long.parseUnsignedLong(s.substring(2), 16);
        return Long.parseLong(s);
    }
}
