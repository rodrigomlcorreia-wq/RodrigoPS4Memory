package pt.rodrigo.ps4memory;

import java.util.concurrent.*;

final class FreezeManager implements AutoCloseable {
    private final ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();
    private ScheduledFuture<?> task;

    synchronized void start(Ps4DebugClient client, int pid, long address, byte[] value) {
        stop();
        byte[] copy = value.clone();
        task = timer.scheduleAtFixedRate(() -> {
            try { client.writeMemory(pid, address, copy); } catch (Exception ignored) {}
        }, 0, 250, TimeUnit.MILLISECONDS);
    }

    synchronized void stop() {
        if (task != null) { task.cancel(false); task = null; }
    }

    synchronized boolean active() { return task != null && !task.isCancelled(); }

    @Override public void close() { stop(); timer.shutdownNow(); }
}
