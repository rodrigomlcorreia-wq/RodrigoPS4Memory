package pt.rodrigo.ps4memory;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class Ps4DebugClient implements Closeable {
    static final int PORT = 744;
    private static final int MAGIC = 0xFFAABBCC;
    private static final int SUCCESS = 0x80000000;
    private static final int CMD_VERSION = 0xBD000001;
    private static final int CMD_PROC_LIST = 0xBDAA0001;
    private static final int CMD_PROC_READ = 0xBDAA0002;
    private static final int CMD_PROC_WRITE = 0xBDAA0003;
    private static final int CMD_PROC_MAPS = 0xBDAA0004;

    private Socket socket;
    private InputStream in;
    private OutputStream out;

    synchronized void connect(String host, int timeoutMs) throws IOException {
        close();
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, PORT), timeoutMs);
        s.setSoTimeout(15000);
        s.setTcpNoDelay(true);
        socket = s;
        in = new BufferedInputStream(s.getInputStream(), 1 << 16);
        out = new BufferedOutputStream(s.getOutputStream(), 1 << 16);
    }

    synchronized boolean isConnected() { return socket != null && socket.isConnected() && !socket.isClosed(); }

    synchronized String version() throws IOException {
        sendHeader(CMD_VERSION, 0);
        int len = readIntLE();
        if (len < 0 || len > 4096) throw new IOException("Resposta VERSION invalida: " + len);
        return new String(readFully(len), StandardCharsets.UTF_8).replace("\0", "").trim();
    }

    synchronized List<Models.ProcessInfo> listProcesses() throws IOException {
        sendHeader(CMD_PROC_LIST, 0);
        expectSuccess();
        long nUnsigned = Integer.toUnsignedLong(readIntLE());
        if (nUnsigned > 4096) throw new IOException("Numero de processos invalido: " + nUnsigned);
        int n = (int)nUnsigned;
        List<Models.ProcessInfo> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            byte[] nameBytes = readFully(32);
            int pid = readIntLE();
            list.add(new Models.ProcessInfo(cString(nameBytes), pid));
        }
        return list;
    }

    synchronized List<Models.MemoryMap> maps(int pid) throws IOException {
        byte[] body = le(4).putInt(pid).array();
        sendPacket(CMD_PROC_MAPS, body, null);
        expectSuccess();
        long nUnsigned = Integer.toUnsignedLong(readIntLE());
        if (nUnsigned > 100000) throw new IOException("Numero de maps invalido: " + nUnsigned);
        int n = (int)nUnsigned;
        List<Models.MemoryMap> maps = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            byte[] raw = readFully(64);
            ByteBuffer b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
            long start = b.getLong();
            long end = b.getLong();
            long offset = b.getLong();
            long prot = b.getLong();
            byte[] name = new byte[32]; b.get(name);
            maps.add(new Models.MemoryMap(start, end, offset, prot, cString(name)));
        }
        return maps;
    }

    synchronized byte[] readMemory(int pid, long address, int length) throws IOException {
        if (length < 0 || length > 16 * 1024 * 1024) throw new IllegalArgumentException("length fora do limite");
        ByteBuffer b = le(16);
        b.putInt(pid).putLong(address).putInt(length);
        sendPacket(CMD_PROC_READ, b.array(), null);
        expectSuccess();
        return readFully(length);
    }

    synchronized void writeMemory(int pid, long address, byte[] data) throws IOException {
        if (data == null || data.length == 0) throw new IllegalArgumentException("Sem dados");
        ByteBuffer b = le(16);
        b.putInt(pid).putLong(address).putInt(data.length);
        sendPacket(CMD_PROC_WRITE, b.array(), data);
        expectSuccess();
    }

    private void sendHeader(int cmd, int dataLen) throws IOException {
        ByteBuffer h = le(12).putInt(MAGIC).putInt(cmd).putInt(dataLen);
        out.write(h.array()); out.flush();
    }

    private void sendPacket(int cmd, byte[] body, byte[] trailing) throws IOException {
        int bodyLen = body == null ? 0 : body.length;
        int extra = trailing == null ? 0 : trailing.length;
        // ps4debug-NG datalen is the fixed request body; trailing write bytes follow it.
        ByteBuffer h = le(12).putInt(MAGIC).putInt(cmd).putInt(bodyLen);
        out.write(h.array());
        if (bodyLen > 0) out.write(body);
        if (extra > 0) out.write(trailing);
        out.flush();
    }

    private void expectSuccess() throws IOException {
        int status = readIntLE();
        if (status != SUCCESS) throw new IOException(String.format("PS4 respondeu status 0x%08X", status));
    }

    private int readIntLE() throws IOException {
        return ByteBuffer.wrap(readFully(4)).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    private byte[] readFully(int n) throws IOException {
        byte[] data = new byte[n];
        int off = 0;
        while (off < n) {
            int r = in.read(data, off, n - off);
            if (r < 0) throw new EOFException("Ligacao fechada pela PS4");
            off += r;
        }
        return data;
    }

    private static ByteBuffer le(int size) { return ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN); }

    private static String cString(byte[] bytes) {
        int n = 0; while (n < bytes.length && bytes[n] != 0) n++;
        return new String(bytes, 0, n, StandardCharsets.UTF_8).trim();
    }

    @Override public synchronized void close() {
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
        socket = null; in = null; out = null;
    }
}
