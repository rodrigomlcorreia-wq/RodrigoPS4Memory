plugins {
    id("com.android.application")
}

android {
    namespace = "pt.rodrigo.ps4memory"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.rodrigo.ps4memory"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
