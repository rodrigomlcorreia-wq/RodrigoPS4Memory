# Rodrigo PS4 Memory

Protótipo Android de analisador de memória para **PS4 jailbroken** usando o protocolo **ps4debug-NG** na porta TCP 744.

## V0.1

- Ligar à PS4 pelo IP
- Mostrar versão do ps4debug-NG
- Listar processos e selecionar `eboot.bin`
- Ler memory maps
- Scan exato de INT8/INT16/INT32/INT64/FLOAT/DOUBLE
- Refinar resultados: Exato, Mudou, Igual, Aumentou, Diminuiu
- Ler e escrever o endereço selecionado
- Freeze de valor a cada 250 ms
- Scanner cliente: usa apenas PROC_LIST/MAPS/READ/WRITE e não depende do handshake AUTH do scanner server-side

## Preparar a PS4

1. PS4 com jailbreak/GoldHEN.
2. Carregar o payload `ps4debug-NG` compatível com o firmware.
3. Confirmar que o telemóvel e a PS4 estão na mesma rede.
4. Abrir a app, colocar o IP da PS4 e tocar em **Ligar**.
5. Selecionar `eboot.bin`.

## Exemplo - encontrar pontos de habilidade

1. Tipo: INT32.
2. Se tens 5 pontos, pesquisa `5`.
3. No jogo, gasta 1 ponto.
4. Na app, escreve `4` e toca **Exato**.
5. Repete até sobrarem poucos endereços.
6. Testa escrever um valor pequeno e verifica o jogo.
7. Só depois usa Freeze.

## Segurança

- Faz backup do save antes de escrever valores.
- Usa apenas na tua própria consola/processos.
- Não faças Freeze de muitos endereços ao mesmo tempo.
- Se o jogo crashar, fecha-o totalmente; as alterações de RAM desaparecem ao reiniciar o processo.

## Compilar

Abrir esta pasta no Android Studio (JDK 17+) e executar `assembleDebug`.
O projeto não usa bibliotecas externas de UI; apenas Android SDK.
